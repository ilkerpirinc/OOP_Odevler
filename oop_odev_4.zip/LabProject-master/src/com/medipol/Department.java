package com.medipol;

public class Department {
	public String name;
	
	public void addInstructor(Instructor instructor ) {
	}
	
	public void removeInstructor(Instructor instructor) {
		
	}
	
	public Instructor getInstructor(int instructorId) {
		return null; // ??
	}
	
	public Instructor[] getAllInstructors() {
			return null;
	}
}
	

	
