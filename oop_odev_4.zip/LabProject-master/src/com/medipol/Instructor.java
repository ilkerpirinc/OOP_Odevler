package com.medipol;

public class Instructor {
	public String name;
	public int id;

}
