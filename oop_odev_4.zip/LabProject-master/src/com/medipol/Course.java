package com.medipol;

public class Course {
	public String name;
	public int courseId;
	public boolean courseStatus;
}
