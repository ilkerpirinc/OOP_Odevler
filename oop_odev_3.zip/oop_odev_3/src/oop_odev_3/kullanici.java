package oop_odev_3;

public class kullanici {
	
	public String name;
	public String surname;
	
	
	
	public void researchBooks(Book book){
		Search research = new search;
		
		
	}

	public void adviceSite() {
		
		
	}
	
	public void seeArticleTitles() {
		
	}
	
	public void signUp() {
		
		
	}
	
	
	
}

